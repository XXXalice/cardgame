from setuptools import setup

setup(
    packages=[
        'cardgame'
    ],
    name='cardgame',
    version='1.1',
    description='Building cardgame library',
    author='umemiya',
    author_email='euthanasia045@gmail.com',
    license='MIT',

    keywords='card cardgame'
)
# Indroduction
It is a library that can be used to produce card games.

# Install

```
pip install cardgame
```

# Licence
MIT